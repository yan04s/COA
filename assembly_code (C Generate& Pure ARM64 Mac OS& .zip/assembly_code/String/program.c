#include <stdio.h>

/*int main() {
    int result;

    // Inline assembly to add 3 and 10
    asm("mov w0, #3\n\t"
        "mov w1, #10\n\t"
        "add %w0, w0, w1"
        : "=r" (result)  // Output operand
        :                // Input operand
        : "w0", "w1"     // Clobbered registers
    );

    // Print the result
    printf("Result: %d\n", result);

    return 0;
}*/

int main() {
    long long result; // Use a 64-bit data type

    // Large constants
    long long large_values[] = {13297845LL, 724179LL, 17060000LL, /* Add more values here */};

    // Inline assembly to add multiple 64-bit constants
    asm("mov x0, %1\n\t"
        "mov x1, %2\n\t"
        "mov x2, %3\n\t"
        //"mov x3, %4\n\t"
        // Add more "mov" instructions for additional values
        "add %0, x0, x1\n\t"
        "add %0, %0, x2\n\t"
        //"add %0, %0, x3"  // Use %0 to reference the output operand
        : "=r" (result)   // Output operand
        : "r" (large_values[0]), "r" (large_values[1]), "r" (large_values[2])//, "r" (large_values[3]) // Input operands
        : "x0", "x1", "x2"//, "x3"      // Clobbered registers
    );

    // Print the result
    printf("Result: %lld\n", result);

    return 0;
}
